import { createContext } from "react";
const GameContext = createContext(null);
export default GameContext;